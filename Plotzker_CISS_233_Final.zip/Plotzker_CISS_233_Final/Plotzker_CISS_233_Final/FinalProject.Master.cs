﻿/*
Kevin Plotzker
CISS 233
4/27/2016

FinalProjectMaster.cs

This file provides methods for navigation buttons displayed on all pages
*/

using System;

namespace Plotzker_CISS_233_Final {

    public partial class FinalProject : System.Web.UI.MasterPage {

        protected void Page_Load(object sender, EventArgs e) {
          
        }
        //Goes to home page when clicked
        protected void BtnIndex_Click(object sender, EventArgs e) {
            Response.Redirect("Index.aspx");
        }
        //Goes to customer entry page when clicked
        protected void BtnCustomerEntry_Click(object sender, EventArgs e) {
            Response.Redirect("CustomerEntry.aspx");
        }
        //Goes to order entry page when clicked
        protected void BtnOrderEntry_Click(object sender, EventArgs e) {
            Response.Redirect("OrderEntry.aspx");
        }
        //Goes to order view page when clicked
        protected void BtnViewOrders_Click(object sender, EventArgs e) {
            Response.Redirect("ViewOrders.aspx");
        }

        
    }
}