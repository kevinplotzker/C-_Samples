﻿/*
Kevin Plotzker
CISS 233 
4/27/2016

ClassCustomerReturn.cs

This file will define a ClassCustomerReturn object, which will store customer data fields 
returned from database, including the auto-incremented cutomer ID
*/

using System;


namespace Plotzker_CISS_233_Final {

    public class ClassCustomerReturn {

        public ClassCustomerReturn(Int16 id, String firstName, String lastName, String address, 
            String city, String state, String zipCode, String phoneNumber) {

            ID = id;
            FirstName = firstName;
            LastName = lastName;
            Address = address;
            City = city;
            State = state;
            ZipCode = zipCode;
            PhoneNumber = phoneNumber;
        }

        public Int16 ID { get; set; }
        public String FirstName { get; set; }
        public String LastName { get; set; }
        public String Address { get; set; }
        public String City { get; set; }
        public String State { get; set; }
        public String ZipCode { get; set; }
        public String PhoneNumber { get; set; }
    }
}