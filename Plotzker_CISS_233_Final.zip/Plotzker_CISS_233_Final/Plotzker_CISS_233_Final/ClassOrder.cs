﻿/*
Kevin Plotzker
CISS 233 
4/27/2016

ClassOrder.cs

This file will define a ClassOrder object to store customer data fields 
from OrderEntry to be loaded into database
*/

using System;

namespace Plotzker_CISS_233_Final {
    public class ClassOrder {

        public ClassOrder(Int16 customerNumber, Int16 whiteSocks, Int16 brownSocks, 
            Int16 blackSocks, Decimal subtotal, Decimal tax, Decimal total, String date) {

            CustomerNumber = customerNumber;
            BlackSocks = blackSocks;
            WhiteSocks = whiteSocks;
            BrownSocks = brownSocks;
            Subtotal = subtotal;
            Tax = tax;
            Total = total;
            Date = date;  
        }

        public Int16 CustomerNumber { get; set; }
        public Int16 WhiteSocks { get; set; }
        public Int16 BlackSocks { get; set; }
        public Int16 BrownSocks { get; set; }
        public Decimal Subtotal { get; set; }
        public Decimal Tax { get; set; }
        public Decimal Total { get; set; }
        public String Date { get; set; }   
    }
}


