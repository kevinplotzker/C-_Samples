﻿/*
Kevin Plotzker
CISS 233 
4/27/2016

ClassOrderReturn.cs

This file will define a ClassOrderReturn object to send order information back
to DisplayOrders, including the order id
*/

using System;

namespace Plotzker_CISS_233_Final {

    public class ClassOrderReturn {

        public ClassOrderReturn(Int16 orderID, Int16 whitesocks, Int16 brownsocks,  Int16 blacksocks, String date, Decimal subtotal, Decimal tax, Decimal total) {

            OrderID = orderID;
            WhiteSocks = whitesocks;
            BrownSocks = brownsocks;
            BlackSocks = blacksocks;
            Date = date;
            Subtotal = subtotal;
            Tax = tax;
            Total = total; 
        }

        public Int16 OrderID { get; set; }
        public Int16 WhiteSocks { get; set; }
        public Int16 BrownSocks { get; set; }
        public Int16 BlackSocks { get; set; }
        public String Date { get; set; }
        public Decimal Subtotal { get; set; }
        public Decimal Tax { get; set; }
        public Decimal Total { get; set; }   
    }
}