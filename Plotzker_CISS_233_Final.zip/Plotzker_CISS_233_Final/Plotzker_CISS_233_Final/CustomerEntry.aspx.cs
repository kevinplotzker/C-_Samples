﻿/*
Kevin Plotzker
CISS 233 
4/27/2016

CustomerEntry.aspx.cs

This file contains methods utilized in the Customer Entry Form
*/


using System;
using System.Collections.Generic;
using System.Web.UI;


namespace Plotzker_CISS_233_Final {

    public partial class LandingPage : System.Web.UI.Page {

        public static bool isValid;  //Flag for valid form entry
        public static List<ClassCustomer> custList = new List<ClassCustomer>();  //List to send cutomer data to database

        //Method to run when page is initially loaded 
        protected void Page_Load(object sender, EventArgs e) {

            if (!Page.IsPostBack) {  //Only fills the states list on initial page load
                FillStates();  //Adds states to dropdown
                TBCustFName.Focus();  //Gives focus to first name text box
            }
            ClearErrors();  //Clears existing error messages     
        }

        //Method to add states to dropdown list
        private void FillStates() {
            DDCustState.Items.Add("Select State");
            DDCustState.Items.Add("Alabama");
            DDCustState.Items.Add("Alaska");
            DDCustState.Items.Add("Arizona");
            DDCustState.Items.Add("Arkansas");
            DDCustState.Items.Add("California");
            DDCustState.Items.Add("Colorado");
            DDCustState.Items.Add("Connecticut");
            DDCustState.Items.Add("Delaware");
            DDCustState.Items.Add("Florida");
            DDCustState.Items.Add("Georgia");
            DDCustState.Items.Add("Hawaii");
            DDCustState.Items.Add("Idaho");
            DDCustState.Items.Add("Illinois");
            DDCustState.Items.Add("Indiana");
            DDCustState.Items.Add("Iowa");
            DDCustState.Items.Add("Kansas");
            DDCustState.Items.Add("Kentucky");
            DDCustState.Items.Add("Louisiana");
            DDCustState.Items.Add("Maine");
            DDCustState.Items.Add("Maryland");
            DDCustState.Items.Add("Massachusetts");
            DDCustState.Items.Add("Michigan");
            DDCustState.Items.Add("Minnesota");
            DDCustState.Items.Add("Mississippi");
            DDCustState.Items.Add("Missouri");
            DDCustState.Items.Add("Montana");
            DDCustState.Items.Add("Nebraska");
            DDCustState.Items.Add("Nevada");
            DDCustState.Items.Add("New Hampshire");
            DDCustState.Items.Add("New Jersey");
            DDCustState.Items.Add("New Mexico");
            DDCustState.Items.Add("New York");
            DDCustState.Items.Add("North Carolina");
            DDCustState.Items.Add("North Dakota");
            DDCustState.Items.Add("Ohio");
            DDCustState.Items.Add("Oklahoma");
            DDCustState.Items.Add("Oregon");
            DDCustState.Items.Add("Pennsylvania");
            DDCustState.Items.Add("Rhode Island");
            DDCustState.Items.Add("South Carolina");
            DDCustState.Items.Add("South Dakota");
            DDCustState.Items.Add("Tennessee");
            DDCustState.Items.Add("Texas");
            DDCustState.Items.Add("Utah");
            DDCustState.Items.Add("Vermont");
            DDCustState.Items.Add("Virginia");
            DDCustState.Items.Add("Washington");
            DDCustState.Items.Add("West Virginia");
            DDCustState.Items.Add("Wisconsin");
            DDCustState.Items.Add("Wyoming");
            DDCustState.SelectedIndex = 0;
        }

        //Method to clear fields when Clear button is pressed
        private void ClearFields() {
            TBCustFName.Text = "";
            TBCustLName.Text = "";
            TBCustAddress.Text = "";
            TBCustCity.Text = "";
            DDCustState.SelectedIndex = 0;
            TBCustZip.Text = "";
            TBCustPhone.Text = "";
        }

        //Method to clear errors when Clear button is pressed
        private void ClearErrors() {
            LblCustFNameError.Visible = false;
            LblCustLNameError.Visible = false;
            LblCustAddressError.Visible = false;
            LblCustCityError.Visible = false;
            LblCustStateError.Visible = false;
            LblCustZipError.Visible = false;
            LblCustPhoneError.Visible = false;
            LblErrorMessage.Visible = false;
        }

        //Method to check for valid entries when Add Customer button is clicked
        public void CheckValid() {

            isValid = true; //Flag set

            //Checks each textbox for empty entry, changes flag and displays error message if empty
            if (TBCustFName.Text == "") {
                LblCustFNameError.Visible = true;
                LblErrorMessage.Visible = true;
                isValid = false;
            }
            if (TBCustLName.Text == "") {
                LblCustLNameError.Visible = true;
                LblErrorMessage.Visible = true;
                isValid = false;
            }
            if (TBCustAddress.Text == "") {
                LblCustAddressError.Visible = true;
                LblErrorMessage.Visible = true;
                isValid = false;
            }
            if (TBCustCity.Text == "") {
                LblCustCityError.Visible = true;
                LblErrorMessage.Visible = true;
                isValid = false;
            }
            if (DDCustState.SelectedIndex == 0) {
                LblCustStateError.Visible = true;
                LblErrorMessage.Visible = true;
                isValid = false;
            }
            if (TBCustZip.Text == "") {
                LblCustZipError.Visible = true;
                LblErrorMessage.Visible = true;
                isValid = false;
            }
            if (TBCustPhone.Text == "") {
                LblCustPhoneError.Visible = true;
                LblErrorMessage.Visible = true;
                isValid = false;
            }
            if (isValid) {  //Adds data to ClassCustomer object if all fields are filled in
                ClassCustomer newCust = new ClassCustomer(TBCustFName.Text, TBCustLName.Text,
                             TBCustAddress.Text, TBCustCity.Text, DDCustState.Text,
                             TBCustZip.Text, TBCustPhone.Text);

                DataUtilityClass.AddCustomer(newCust);  //Adds customer to database

                ClearFields();  //Clears textboxes and error messages
                ClearErrors();
            }
        }

        //Method to call the validation check method when Add Customer buton is clicked
        protected void BtnAddCustomer_Click(object sender, EventArgs e) {
            CheckValid();
        }

        //Method to clear textboxes and error messages when Clear button is clicked
        protected void BtnClearCustomerFields_Click(object sender, EventArgs e) {
            ClearFields();
            ClearErrors();
        }

        //This method does nothing but DO NOT REMOVE
        protected void TBCustFName_TextChanged1(object sender, EventArgs e) {
            LblCustFNameError.Visible = false;
        }
    }
}