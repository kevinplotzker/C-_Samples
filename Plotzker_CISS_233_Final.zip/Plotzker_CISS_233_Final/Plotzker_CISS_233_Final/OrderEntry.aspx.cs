﻿/*
Kevin Plotzker
CISS 233
4/27/2016

OrderEntry.aspx.cs

This file contains methods used in the Order Entry page
*/

using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Plotzker_CISS_233_Final {

    public partial class OrderEntry : System.Web.UI.Page {

        private List<ClassCustomerReturn> dropdownIDList;  //List to hold customer data from database for dropdown
        public static List<ClassItems> itemsList = new List<ClassItems>();  //List for shopping cart item info
        private String prepend; //To add zeros to beginning of customer id in dropdown, for alignment
        private static Int16 itemIndex;  //Counter to track item numbers for cart view
        public static Decimal subtotal;  //Total order amounts
        public static Decimal tax;
        public static Decimal total;  


        protected void Page_Load(object sender, EventArgs e) {
            //Uncomment following two lines to clear customers and orders table
            //DataUtilityClass.ClearCustomerTable();
            //DataUtilityClass.ClearOrdersTable();
           

            if (!Page.IsPostBack) {  //Only does th following on initial page load
                FillIDList();  //Fills dropdowns
                FillColorList();
                FillQuantityList();
                FillRemoveItemList();
                DPOrderDate.SelectedDate = DateTime.Today;  //Sets calendar to current date
                DPOrderDate.BorderColor = System.Drawing.Color.Black;  //Gives border to calendar
                ClearOrderErrors();  //Clears errors
                itemIndex = 0;  //Sets item counter
                DivCart.Visible = false;  //Hides cart view label and remove button
                CalculateCost();  //Sets money textboxes to 0
                DDOrderCustID.Focus(); //Gives focus to first dropdown
            }
        }

        //Method to query database and add existing customers to dropdown
        private void FillIDList() {

            dropdownIDList = DataUtilityClass.GetCustomerID();  //Gets customer ID and name
            DDOrderCustID.Items.Add("Select Customer");

            if (dropdownIDList.Count != 0) {  //Skips if no customer have been added, to avoid errors
                for (int i = 0; i < dropdownIDList.Count; i++) {  //Loops through ID list
                    Int16 idNum = dropdownIDList[i].ID;  //Gets ID number and prepends zeros, for alignment in dropdown
                    if (idNum < 10) {
                        prepend = "00";  //Adds two zeros to single digit IDs
                    }
                    else if (idNum < 100) {  //Adds one zero to double digit IDs
                        prepend = "0";
                    }
                    else {
                        prepend = "";  //Leaves triple digit IDs as is
                    }
                    String id = prepend + dropdownIDList[i].ID.ToString();  //Formats text
                    String first = dropdownIDList[i].FirstName.ToString();
                    String last = dropdownIDList[i].LastName.ToString();
                    String cust = id + " - " + last + ", " + first;
                    DDOrderCustID.Items.Add(cust);  //Adds to dropdown list
                }
            }
            DDOrderCustID.SelectedIndex = 0;
        }

        //Buttom to call ChangeCustomer when customer dropdown changes
        protected void DDOrderCustID_SelectedIndexChanged(object sender, EventArgs e) {
            ChangeCustomer();
        }
        public void ChangeCustomer() {
            itemsList.Clear();  //Clears cart
            CalculateCost();  //Resets money textboxes
            itemIndex = 0;  //Resets item index
            BuildCartView();  //Hides cart div
            DPOrderDate.SelectedDate = DateTime.Today;  //Resets calendar
        }

        //When date is changed, rebuilds cart to avoid errors
        protected void DPOrderDate_SelectionChanged(object sender, EventArgs e) {
            BuildCartView();
        }

        //Method to add colors to dropdown
        private void FillColorList() {
            DDColor.Items.Add("Select Color");
            DDColor.Items.Add("White");
            DDColor.Items.Add("Brown");
            DDColor.Items.Add("Black");
            DDColor.SelectedIndex = 0;
        }

        //Method to add numbers to quantity dropdown
        private void FillQuantityList() {
            DDQuantity.Items.Add("Select Quantity");
            for (int i = 1; i < 100; i++) {
                DDQuantity.Items.Add(i.ToString());
            }
            DDQuantity.SelectedIndex = 0;
        }

        //Method to check if item can be added to cart, called from Add to Cart button
        protected void BtnAddCart_Click(object sender, EventArgs e) {
            CheckValidCart();
        }
        public void CheckValidCart() {

            ClearOrderErrors();  //Clears errors
            bool isValid = true;   //Sets flag

            if (DDOrderCustID.SelectedIndex == 0) {  //Cehcks for customer
                LblIDError.Visible = true;
                isValid = false;
            }
            if (DDColor.SelectedIndex == 0) {  //Checks for color
                LblItemError.Visible = true;
                isValid = false;
            }
            if (DDQuantity.SelectedIndex == 0) {  //Checks for quantity
                LblItemError.Visible = true;
                isValid = false;
            }
            if (isValid) {  //Adds to cart if valid
                itemIndex++;  
                itemsList.Add(new ClassItems(itemIndex, DDColor.Text, Convert.ToInt16(DDQuantity.Text)));
                BuildCartView();  //Displays cart
                CalculateCost();  //Updates cost
                FillRemoveItemList();  //Adds item number to remove item dropdown
                ClearItemFields();  //Resets item dropdowns
                ClearOrderErrors();  //Clears errors
            }
        }

        //Method to calculate subtotal, tax, and total when items are added or removed from cart
        public void CalculateCost() {

            subtotal = 0;

            for (int i = 0; i < itemsList.Count; i++) {  //Loops through items list
                if (itemsList[i].Color == "White") {
                    subtotal += Convert.ToDecimal(itemsList[i].Quantity) * 10;  //Adds 10 for whte socks
                }
                else if (itemsList[i].Color == "Brown") {
                    subtotal += Convert.ToDecimal(itemsList[i].Quantity) * 11;  //Adds 11 for brown socks
                }
                else {
                    subtotal += Convert.ToDecimal(itemsList[i].Quantity) * 12;  //Adds 12 for black socks
                }
            }
            TBSubtotal.Text = String.Format("{0:c}", subtotal);  //Prints subtotal

            tax = (subtotal * .08m);  //Calculates and prints 8% tax
            TBTax.Text = String.Format("{0:c}", tax);

            total = subtotal + tax;  //Calculates and prints total
            TBTotal.Text = String.Format("{0:c}", total);
        }

        //Method to display cart when item has been added or removed
        public void BuildCartView() {

            if (itemsList.Count != 0) {  //Displays cart div if items exist
                DivCart.Visible = true;

                TableHeaderRow headerRow = new TableHeaderRow();  //Creates header row
                TblCurrentCart.Rows.Add(headerRow);
                headerRow.BorderColor = System.Drawing.Color.Black;

                TableHeaderCell itemNbr = new TableHeaderCell();  //Creates header columns
                itemNbr.Text = "Item Number";
                itemNbr.Width = 100;

                TableHeaderCell itemColor = new TableHeaderCell();
                itemColor.Text = "Item Color";
                itemColor.Width = 100;

                TableHeaderCell itemQuantity = new TableHeaderCell();
                itemQuantity.Text = "Item Quantity";
                itemQuantity.Width = 100;

                headerRow.Cells.Add(itemNbr);  //Adds columns to table
                headerRow.Cells.Add(itemColor);
                headerRow.Cells.Add(itemQuantity);

                for (int i = 0; i < itemsList.Count; i++) {  //Loops through list, adds data to cells
                    TableRow newRow = new TableRow();
                    newRow.BorderColor = System.Drawing.Color.Black;
                    TblCurrentCart.Rows.Add(newRow);

                    TableCell newItemNbr = new TableCell();
                    newItemNbr.Text = itemsList[i].ItemNumber.ToString();
                    newItemNbr.Width = 100;
                    newItemNbr.HorizontalAlign = HorizontalAlign.Right;
                    newRow.Cells.Add(newItemNbr);

                    TableCell newItemColor = new TableCell();
                    newItemColor.Text = itemsList[i].Color;
                    newItemColor.Width = 100;
                    newItemColor.HorizontalAlign = HorizontalAlign.Right;
                    newRow.Cells.Add(newItemColor);

                    TableCell newItemQuantity = new TableCell();
                    newItemQuantity.Text = itemsList[i].Quantity.ToString();
                    newItemQuantity.Width = 100;
                    newItemQuantity.HorizontalAlign = HorizontalAlign.Right;
                    newRow.Cells.Add(newItemQuantity);
                }
            }
            else {
                DivCart.Visible = false;  //Hides cart if no items exist
            }
        }

        //Method to add item numbers to dropdown, to allow removal from cart
        public void FillRemoveItemList() {
            DDRemoveItem.Items.Clear();  //Clears dropdown
            DDRemoveItem.Items.Add("Select Item Number");
            if (itemsList.Count != 0) {  //If items are in cart, loops through itemsList and adds itemNumber to dropdown
                for (int i = 0; i < itemsList.Count; i++) {
                    DDRemoveItem.Items.Add(itemsList[i].ItemNumber.ToString());
                }
            }
            DDRemoveItem.SelectedIndex = 0;
        }

        //Method to reset item dropdowns after item added to cart
        private void ClearItemFields() {  
            DDColor.SelectedIndex = 0;
            DDQuantity.SelectedIndex = 0;   
        }

        //Method to clear error messages when item added to cart
        private void ClearOrderErrors() {
            LblIDError.Visible = false;
            LblDateError.Visible = false;
            LblItemError.Visible = false;
            LblRemoveError.Visible = false;
        }

        //Method to Remove items from cart when Remove Item button is clicked
        protected void BtnRemoveItem_Click(object sender, EventArgs e) {
            RemoveItem();
        }
        private void RemoveItem() {
            if (DDRemoveItem.SelectedIndex == 0) {  //Displays error if no item selected
                BuildCartView();
                LblRemoveError.Visible = true;
            }
            else {
                LblRemoveError.Visible = false; 
                ClassItems removalItem = itemsList[DDRemoveItem.SelectedIndex - 1];  //Gets number of selected item
                itemsList.Remove(removalItem);  //Removes item
                if (itemsList.Count == 0) {  //Resets index counter to zero if no items are left in cart
                    itemIndex = 0;
                }
                CalculateCost();  //Updates cost
                BuildCartView();  //Updates cart
                FillRemoveItemList();  //Fills removal list
            }
        }
          
        //Method to add items to order and store in database, called from Place Order button
        protected void BtnPlaceOrder_Click(object sender, EventArgs e) {
            PlaceOrder();
        }
        private void PlaceOrder() {
            String cNum = DDOrderCustID.Text.Substring(0, 3);  //Gets customer ID from dropdown
            String date = DPOrderDate.SelectedDate.ToString();  //Gets date
            int dateLength = date.Length;  //Truncates date, to get rid of time
            dateLength -= 11;
            String shortDate = date.Substring(0, dateLength);

            Int16 white = 0;  //Counters for each sock color
            Int16 black = 0;
            Int16 brown = 0;

            for (int i = 0; i < itemsList.Count; i++) {  //Loops through itemList, increments colors
                if (itemsList[i].Color == "White") {
                    white += itemsList[i].Quantity;
                }
                if (itemsList[i].Color == "Brown") {
                    brown += itemsList[i].Quantity;
                }
                if (itemsList[i].Color == "Black") {
                    black += itemsList[i].Quantity;
                }
            }
            ClassOrder order = new ClassOrder(Convert.ToInt16(cNum), white, brown, black, subtotal, tax, total, shortDate);  //Creates order object
            DataUtilityClass.AddOrder(order);  //Adds order to database
            itemsList.Clear();  //Clears itemsList
            DPOrderDate.SelectedDate = DateTime.Today;  //Resets date
            CalculateCost();  //Resets cost
            DDOrderCustID.SelectedIndex = 0;  //Resets cutomer dropdown
            BuildCartView();  //Resets cart - will be empty and hidden
            DDOrderCustID.Focus();  //Gives focus to top dropdown
        }


        //DO NOT DELETE
        protected void BtnClearCurrentOrder_Click(object sender, EventArgs e) {
            //  ClearOrderFields();
        }

    }
}