﻿/*
Kevin Plotzker
CISS 233
4/27/2016

ViewOrders.aspx.cs

//This file contains methods used in ViewOrders.aspx
*/

using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Plotzker_CISS_233_Final {

    public partial class ViewOrders : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {

            if (!Page.IsPostBack) {  //When page is loaded for first time
                DataSet ds = DataUtilityClass.GetData();  //Creates DataSet from DataUtilityClass query
                if(ds.Tables[0].Rows.Count == 0) { //Tests for no orders and displays no orders label if so
                    DivNoOrders.Visible = true;
                }
                else {
                    DivNoOrders.Visible = false;
                }
                GVOrders.DataSource = ds.Tables[0];  //Creates GridView from DataSet if data exists
                GVOrders.DataBind();
                DivSelectOrder.Visible = true;  //Shows all orders div, hides results div
                DivViewOrder.Visible = false;
            }
        }

        //Method to modify GridView formatting
        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e) {

            if (e.Row.RowType == DataControlRowType.Header) {  //Header row formats

                e.Row.Cells[0].Text = "Order Number";  //Specifies title and witdth of columns
                e.Row.Cells[0].Width = 100;

                e.Row.Cells[1].Text = "Order Date";
                e.Row.Cells[1].Width = 120;

                e.Row.Cells[2].Text = "First Name";
                e.Row.Cells[2].Width = 150;

                e.Row.Cells[3].Text = "Last Name";
                e.Row.Cells[3].Width = 150;

                e.Row.Cells[4].Text = "Order Total";
                e.Row.Cells[4].Width = 120;

            }
            if (e.Row.RowType != DataControlRowType.Header) {  //Aligns non-header row text on right
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Right;
                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Right;
                e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Right;
                e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Right;
                e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Right;       
            }

            if (e.Row.RowType == DataControlRowType.DataRow) {
                
                e.Row.Cells[4].Text = "$" + e.Row.Cells[4].Text;  //Adds dollar sign to Order Total
                e.Row.Cells[1].Text = e.Row.Cells[1].Text.Substring(0, e.Row.Cells[1].Text.Length - 11);  //Gets rid of time in date string
            }

            if (e.Row.RowType == System.Web.UI.WebControls.DataControlRowType.DataRow) {

                //When mouse is over the row, save original color to new attribute, and change it to highlight color
                e.Row.Attributes.Add("onmouseover", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='yellow';this.style.cursor='pointer'");
                
                //When mouse leaves the row, change the bg color to its original value   
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=this.originalstyle;");
            }
        }

        //Method to display order details when user clicks row in GridView
        protected void GVOrders_SelectedIndexChanged(object sender, EventArgs e) {

            GridViewRow g = GVOrders.SelectedRow;

            Int16 ordNum = Convert.ToInt16(g.Cells[0].Text);  //Gets order number
            Int16 custNum = DataUtilityClass.GetCustomerNumber(ordNum);  //Gets customer number from database, using order number 

            ClassCustomerReturn customer = DataUtilityClass.GetCustomerForDisplay(custNum);  //Gets customer data from database
            DisplayCustomerInfo(customer);  //Displays customer info on second page div

            ClassOrderReturn order = DataUtilityClass.GetOrder(ordNum);  //Gets order data from database
            DisplayOrderInfo(order);  //Displays order info on second page div

            DivSelectOrder.Visible = false;  //Hides select div, shows customer info and order div
            DivViewOrder.Visible = true;
            BtnBack.Focus();
        }

        //Method to diplay customer data on second div
        private void DisplayOrderInfo(ClassOrderReturn o) {
            DivWhite.Visible = false;
            DivBrown.Visible = false;
            DivBlack.Visible = false;

            LblOrderID.Text = o.OrderID.ToString();
            LblOrderDate.Text = o.Date;
            if (o.WhiteSocks > 0) {
                DivWhite.Visible = true;
                LblWhiteSocks.Text = o.WhiteSocks.ToString();
            }
            if (o.BrownSocks > 0) {
                DivBrown.Visible = true;
                LblBrownSocks.Text = o.BrownSocks.ToString();
            }
            if (o.BlackSocks > 0) {
                DivBlack.Visible = true;
                LblBlackSocks.Text = o.BlackSocks.ToString();
            }
            LblOrderSubtotal.Text = String.Format("{0:c}", o.Subtotal);
            LblOrderTax.Text = String.Format("{0:c}", o.Tax);
            LblOrderTotal.Text = String.Format("{0:c}", o.Total);
        }

        //Method to diplay order data on second div
        private void DisplayCustomerInfo(ClassCustomerReturn c) {
            LblCustomerID.Text = c.ID.ToString();
            LblCustomerName.Text = c.FirstName + " " + c.LastName;
            LblCustomerAddress.Text = c.Address;
            LblCustomerCity.Text = c.City + ", " + c.State;
            LblCustomerZip.Text = c.ZipCode;
            LblCustomerPhone.Text = c.PhoneNumber;
        }

        //Method to make GridView 
        protected override void Render(System.Web.UI.HtmlTextWriter writer) {

            foreach (GridViewRow row in GVOrders.Rows) {  //Makes rows clickable
                if (row.RowType == DataControlRowType.DataRow) {
                     row.Attributes["onclick"] =
                     ClientScript.GetPostBackClientHyperlink(GVOrders,
                        "Select$" + row.DataItemIndex, true);
                }
            }
            base.Render(writer);
        }

        //Method to switch divs and go back to order selection when Back button is clicked
        protected void BtnBack_Click(object sender, EventArgs e) {
            DivSelectOrder.Visible = true;
            DivViewOrder.Visible = false;
        }
    }
}