﻿/*
Kevin Plotzker
CISS 233 
4/27/2016

ClassCustomer.cs

This file will define a ClassCustomer object to store customer data fields 
from CustomerEntry to be loaded into database
*/

using System;


namespace Plotzker_CISS_233_Final {

    public class ClassCustomer {

        public ClassCustomer(String firstName, String lastName, String address,
            String city, String state, String zipCode, String phoneNumber) {

            FirstName = firstName;
            LastName = lastName;
            Address = address;
            City = city;
            State = state;
            ZipCode = zipCode;
            PhoneNumber = phoneNumber;
        }

        public String FirstName { get; set; }
        public String LastName { get; set; }
        public String Address { get; set; }
        public String City { get; set; }
        public String State { get; set; }
        public String ZipCode { get; set; }
        public String PhoneNumber { get; set; }
    }
}
