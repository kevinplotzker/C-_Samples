﻿/*
Kevin Plotzker
CISS 233 
4/27/2016

DataUtilityClass.cs

This file contains methods to connect to database, add data, query database, and close connection
*/

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;


namespace Plotzker_CISS_233_Final {

    public class DataUtilityClass {

        static System.Data.SqlClient.SqlConnection conn = null;

        //Method to connect to local database SocksDB.mdf
        static void ConnectToDB() {
            conn = new System.Data.SqlClient.SqlConnection();
            conn.ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\SocksDB.mdf;Integrated Security=True";
            conn.Open();
        }

        //Method to add customer to database when validated input is saved in CustomerEntry.cs
        static public void AddCustomer(ClassCustomer c) {

            try {
                ConnectToDB();
                string sql = "insert into customers(Customer_FName, Customer_LName, Customer_Address, " +
                              "Customer_City, Customer_State, Customer_Zip, Customer_Phone) " +
                                "values('" + c.FirstName + "', '" + c.LastName + "', '" + c.Address +
                                "', '" + c.City + "', '" + c.State + "', '" + c.ZipCode + "', '" + c.PhoneNumber + "')";
                System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand(sql, conn);
                command.ExecuteNonQuery();
            }
            catch (System.Data.SqlClient.SqlException ex) {
                Console.WriteLine("{0} Exception caught.", ex);
            }
            CloseDBConn();
        }

        //Method to add order to database when validated input is saved in OrderEntry.cs
        static public void AddOrder(ClassOrder o) {

            try {
                ConnectToDB();
                string sql = "insert into orders(Orders_CustID, Orders_WhiteSocks, Orders_BlackSocks, " +
                              "Orders_BrownSocks, Orders_Total, Orders_Date, Orders_Subtotal, Orders_Tax) " +
                                "values('" + o.CustomerNumber + "', '" + o.WhiteSocks + "', '" + o.BlackSocks +
                                "', '" + o.BrownSocks + "', '" + o.Total + "', '" + o.Date + "', '" + o.Subtotal + "', '" + o.Tax + "')";
                System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand(sql, conn);
                command.ExecuteNonQuery();
            }
            catch (System.Data.SqlClient.SqlException ex) {
                Console.WriteLine("{0} Exception caught.", ex);
            }
            CloseDBConn();
        }

        //Mthod to return the customer number given an order number from ViewOrders
        //Used in conjunction with GetCustomerForDisplay() method below to display 
        //customer data after clicking on GridView row in ViewOrders 
        static public Int16 GetCustomerNumber(Int16 onum) {

            Int16 cnum = 0;

            try {
                ConnectToDB();
                string sql = "Select Orders_CustID FROM orders WHERE Orders_ID = " + onum;
                System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand(sql, conn);
                System.Data.SqlClient.SqlDataReader reader = command.ExecuteReader();

                while (reader.Read()) {
                    cnum = Convert.ToInt16(reader["Orders_CustID"]);
                }
            }
            catch (System.Data.SqlClient.SqlException ex) {
                Console.WriteLine("{0} Exception caught.", ex);
            }
            CloseDBConn();
            return cnum;
        }

        //Method to return customer data to ViewOrders
        static public ClassCustomerReturn GetCustomerForDisplay(Int16 cnum) {

            ClassCustomerReturn selectedCustomer = null;

            try {
                ConnectToDB();
                string sql = "SELECT * FROM customers WHERE Customer_ID = " + cnum;
                System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand(sql, conn);
                System.Data.SqlClient.SqlDataReader reader = command.ExecuteReader();

                while (reader.Read()) {
                    selectedCustomer = new ClassCustomerReturn(Convert.ToInt16(reader["Customer_ID"]), reader["Customer_FName"].ToString(), reader["Customer_LName"].ToString(),
                        reader["Customer_Address"].ToString(), reader["Customer_City"].ToString(),
                        reader["Customer_State"].ToString(), reader["Customer_Zip"].ToString(),
                        reader["Customer_Phone"].ToString());
                }
            }
            catch (System.Data.SqlClient.SqlException ex) {
                selectedCustomer = null;
                Console.WriteLine("{0} Exception caught.", ex);
            }
            CloseDBConn();
            return selectedCustomer;
        }

        //Method to get all customer fields, including ID, since it is generated by DB and is not part of the insert data
        //USed to generate customer selection dropdown in OrderEntry 
        static public List<ClassCustomerReturn> GetCustomerID() {

            List<ClassCustomerReturn> IDList = new List<ClassCustomerReturn>();

            try {
                ConnectToDB();
                string sql = "SELECT * FROM customers ORDER BY Customer_LName";
                System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand(sql, conn);
                System.Data.SqlClient.SqlDataReader reader = command.ExecuteReader();

                while (reader.Read()) {
                    IDList.Add(new ClassCustomerReturn(Convert.ToInt16(reader["Customer_ID"]), reader["Customer_FName"].ToString(), reader["Customer_LName"].ToString(),
                        reader["Customer_Address"].ToString(), reader["Customer_City"].ToString(),
                        reader["Customer_State"].ToString(), reader["Customer_Zip"].ToString(),
                        reader["Customer_Phone"].ToString()));
                }
            }
            catch (System.Data.SqlClient.SqlException ex) {
                IDList = null;
                Console.WriteLine("{0} Exception caught.", ex);
            }
            CloseDBConn();
            return IDList;
        }

        //Mthod to get order data for display in ViewOrders   
        static public ClassOrderReturn GetOrder(Int16 onum) {

            ClassOrderReturn order = null;

            try {
                ConnectToDB();
                string sql = "SELECT * FROM orders WHERE Orders_ID = " + onum;
                System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand(sql, conn);
                System.Data.SqlClient.SqlDataReader reader = command.ExecuteReader();

                while (reader.Read()) {
                    order = new ClassOrderReturn(Convert.ToInt16(reader["Orders_ID"]), Convert.ToInt16(reader["Orders_WhiteSocks"]), Convert.ToInt16(reader["Orders_BrownSocks"]),
                       Convert.ToInt16(reader["Orders_BlackSocks"]), Convert.ToDateTime(reader["Orders_Date"]).ToShortDateString(), Convert.ToDecimal(reader["Orders_Subtotal"]),
                        Convert.ToDecimal(reader["Orders_Tax"]), Convert.ToDecimal(reader["Orders_Total"]));
                }
            }
            catch (System.Data.SqlClient.SqlException ex) {
                order = null;
                Console.WriteLine("{0} Exception caught.", ex);
            }
            CloseDBConn();
            return order;
        }

        //Method to generate a GridView to diplay all orders in ViewOrders
        static public DataSet GetData() {

            String connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\SocksDB.mdf;Integrated Security=True";
            
            String queryString = "Select Orders.Orders_ID, Orders.Orders_Date, Customers.Customer_FName, " +
                "Customers.Customer_LName, Orders.Orders_Total FROM Orders INNER JOIN Customers " +
                    "ON Orders.Orders_CustID = Customers.Customer_ID ORDER BY Customers.Customer_LName";

            DataSet ds = new DataSet();

            try {

                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand Cmd = new SqlCommand(queryString, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
                adapter.Fill(ds);
            }
            catch (Exception ex) {
                Console.WriteLine("{0} Exception caught.", ex);
            }
            return ds;
        }

        //Method to close connection after inserting rows or retrieving data
        static public void CloseDBConn() {
            conn.Close();
        }




        //-------------------------DEVELOPER USE ONLY------------------------------//





        //Methods to delete data from tables- developer use only
        static public void ClearCustomerTable() {
            try {
                ConnectToDB();
                string sql = "Delete From Customers";
                System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand(sql, conn);
                command.ExecuteNonQuery();
            }
            catch (System.Data.SqlClient.SqlException ex) {
                Console.WriteLine("{0} Exception caught.", ex);
            }
            CloseDBConn();
        }
        static public void ClearOrdersTable() {
            try {
                ConnectToDB();
                string sql = "Delete From Orders";
                System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand(sql, conn);
                command.ExecuteNonQuery();
            }
            catch (System.Data.SqlClient.SqlException ex) {
                Console.WriteLine("{0} Exception caught.", ex);
            }
            CloseDBConn();
        }
    }
}