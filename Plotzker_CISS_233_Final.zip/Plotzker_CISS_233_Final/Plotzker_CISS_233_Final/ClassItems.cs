﻿/*
Kevin Plotzker
CISS 233 
4/27/2016

ClassItem.cs

This file will define a ClassItem object to store item information
to build a cart view table in OrderEntry
*/

using System;

namespace Plotzker_CISS_233_Final {

    public class ClassItems {

        public ClassItems(Int16 itemNumber, String color, Int16 quantity) {
            ItemNumber = itemNumber;
            Color = color;
            Quantity = quantity;   
        }

        public Int16 ItemNumber { get; set; }
        public String Color { get; set; }
        public Int16 Quantity { get; set; }
    }
}
