﻿using System;


namespace Plotzker_CISS_233_Final {

    public partial class Index : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {

        }
    }
}