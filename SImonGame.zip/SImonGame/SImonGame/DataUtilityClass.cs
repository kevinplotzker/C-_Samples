﻿/*
    Kevin Plotzker
    CISS 233
    4/11/2016

    DataUtilityClass.cs

    This program will connect to a local database to store the high scores 
    achieved in the Simon Game in SimonForm.cs.  Methods are provided to get the number 
    of stored scores, retrieve the highest score, add a new high score, and clear the table
*/

using System;

namespace SImonGame {

   public class DataUtilityClass{

        public static int count;  //Variables to hold results of COUNT and MAX queries
        public static int max;
        static System.Data.SqlClient.SqlConnection conn = null;  //Connection object variable

        //Method to connect to local database SimonScores.mdf
        static void ConnectToDB() {
            conn = new System.Data.SqlClient.SqlConnection();
            conn.ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\SimonScores.mdf;Integrated Security=True";
            conn.Open();
        }

        //Method to query database to determine if scores have been entered
        static public int checkForScores() {
            //int count;
            try {
                ConnectToDB();
                string sql = "select count(score) from scores";
                System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand(sql, conn);
                count = (Int32)command.ExecuteScalar();
            }
            catch (System.Data.SqlClient.SqlException ex) {
                Console.WriteLine("{0} Exception caught.", ex);
                count = 0;
            }
            CloseDBConn();
            return count;
        }

        //Method to query database for highest score, if scores have been entered
        static public int getMaxScore() {
            try {
                ConnectToDB();
                string sql = "select max(score) from scores";
                System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand(sql, conn);
                max = (Int32)command.ExecuteScalar();
            }
            catch (System.Data.SqlClient.SqlException ex) {
                Console.WriteLine("{0} Exception caught.", ex);
                max = 0;
            }
            CloseDBConn();
            return max;
        }

        //Method to add a new highest score to database
        static public void AddScore(String highScore) {  //highScore is passed from textbox on SimonForm
            try {
                ConnectToDB();
                int addedScore = Convert.ToInt16(highScore);  //Converts textbox string to int
                string sql = "insert into Scores(Score) values(" + addedScore + ")";  //Query assigned to variable
                System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand(sql, conn);
                command.ExecuteNonQuery();  //Adds score to database
            }
            catch (System.Data.SqlClient.SqlException ex) {
                Console.WriteLine("{0} Exception caught.", ex);
            }
            CloseDBConn();
        }

        //Method to clear database 
        static public void ResetHighScore() {
            try {
                ConnectToDB();
                string sql = "delete from Scores";  //Query assigned to variable
                System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand(sql, conn);
                command.ExecuteNonQuery();  //Deletes scores from database
            }
            catch (System.Data.SqlClient.SqlException ex) {
                Console.WriteLine("{0} Exception caught.", ex);
            }
            CloseDBConn();
        }

        //Method to close connection after inserting rows or retrieving data
        static public void CloseDBConn() {
            conn.Close();
        }
    }
}
