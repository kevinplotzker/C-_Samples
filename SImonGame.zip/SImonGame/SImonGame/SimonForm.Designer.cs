﻿namespace SImonGame {
    partial class FrmSimon {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.BtnStart = new System.Windows.Forms.Button();
            this.LblCurrentScore = new System.Windows.Forms.Label();
            this.TBCurrentScore = new System.Windows.Forms.TextBox();
            this.LblHighScore = new System.Windows.Forms.Label();
            this.TBHighScore = new System.Windows.Forms.TextBox();
            this.BtnGreen = new System.Windows.Forms.Button();
            this.BtnRed = new System.Windows.Forms.Button();
            this.BtnYellow = new System.Windows.Forms.Button();
            this.BtnBlue = new System.Windows.Forms.Button();
            this.PnlPlayerButtons = new System.Windows.Forms.Panel();
            this.LblGameOver = new System.Windows.Forms.Label();
            this.PnlComputerButtons = new System.Windows.Forms.Panel();
            this.PnlBlue = new System.Windows.Forms.Panel();
            this.PnlYellow = new System.Windows.Forms.Panel();
            this.PnlRed = new System.Windows.Forms.Panel();
            this.PnlGreen = new System.Windows.Forms.Panel();
            this.LblTitle = new System.Windows.Forms.Label();
            this.LblHighScoreMessage = new System.Windows.Forms.Label();
            this.BtnReset = new System.Windows.Forms.Button();
            this.BtnTurboMode = new System.Windows.Forms.Button();
            this.PnlPlayerButtons.SuspendLayout();
            this.PnlComputerButtons.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnStart
            // 
            this.BtnStart.BackColor = System.Drawing.Color.Gainsboro;
            this.BtnStart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnStart.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.BtnStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnStart.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnStart.ForeColor = System.Drawing.Color.Green;
            this.BtnStart.Location = new System.Drawing.Point(191, 179);
            this.BtnStart.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.BtnStart.Name = "BtnStart";
            this.BtnStart.Size = new System.Drawing.Size(357, 100);
            this.BtnStart.TabIndex = 0;
            this.BtnStart.Text = "START";
            this.BtnStart.UseVisualStyleBackColor = false;
            this.BtnStart.Click += new System.EventHandler(this.BtnStart_Click);
            // 
            // LblCurrentScore
            // 
            this.LblCurrentScore.AutoSize = true;
            this.LblCurrentScore.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblCurrentScore.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LblCurrentScore.Location = new System.Drawing.Point(639, 158);
            this.LblCurrentScore.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LblCurrentScore.Name = "LblCurrentScore";
            this.LblCurrentScore.Size = new System.Drawing.Size(158, 44);
            this.LblCurrentScore.TabIndex = 1;
            this.LblCurrentScore.Text = "My Score";
            // 
            // TBCurrentScore
            // 
            this.TBCurrentScore.BackColor = System.Drawing.Color.Black;
            this.TBCurrentScore.Cursor = System.Windows.Forms.Cursors.Default;
            this.TBCurrentScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBCurrentScore.ForeColor = System.Drawing.Color.Red;
            this.TBCurrentScore.Location = new System.Drawing.Point(859, 155);
            this.TBCurrentScore.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.TBCurrentScore.MaximumSize = new System.Drawing.Size(99, 40);
            this.TBCurrentScore.MinimumSize = new System.Drawing.Size(99, 40);
            this.TBCurrentScore.Name = "TBCurrentScore";
            this.TBCurrentScore.ReadOnly = true;
            this.TBCurrentScore.Size = new System.Drawing.Size(99, 50);
            this.TBCurrentScore.TabIndex = 2;
            this.TBCurrentScore.TabStop = false;
            this.TBCurrentScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LblHighScore
            // 
            this.LblHighScore.AutoSize = true;
            this.LblHighScore.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblHighScore.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LblHighScore.Location = new System.Drawing.Point(639, 251);
            this.LblHighScore.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.LblHighScore.Name = "LblHighScore";
            this.LblHighScore.Size = new System.Drawing.Size(184, 44);
            this.LblHighScore.TabIndex = 3;
            this.LblHighScore.Text = "High Score";
            // 
            // TBHighScore
            // 
            this.TBHighScore.BackColor = System.Drawing.Color.Black;
            this.TBHighScore.Cursor = System.Windows.Forms.Cursors.Default;
            this.TBHighScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBHighScore.ForeColor = System.Drawing.Color.Red;
            this.TBHighScore.Location = new System.Drawing.Point(859, 249);
            this.TBHighScore.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.TBHighScore.MaximumSize = new System.Drawing.Size(99, 40);
            this.TBHighScore.MinimumSize = new System.Drawing.Size(99, 40);
            this.TBHighScore.Name = "TBHighScore";
            this.TBHighScore.ReadOnly = true;
            this.TBHighScore.Size = new System.Drawing.Size(99, 50);
            this.TBHighScore.TabIndex = 4;
            this.TBHighScore.TabStop = false;
            this.TBHighScore.Text = "0";
            this.TBHighScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // BtnGreen
            // 
            this.BtnGreen.BackColor = System.Drawing.Color.Green;
            this.BtnGreen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnGreen.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Lime;
            this.BtnGreen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnGreen.Location = new System.Drawing.Point(35, 31);
            this.BtnGreen.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.BtnGreen.Name = "BtnGreen";
            this.BtnGreen.Size = new System.Drawing.Size(404, 260);
            this.BtnGreen.TabIndex = 5;
            this.BtnGreen.UseVisualStyleBackColor = false;
            this.BtnGreen.Click += new System.EventHandler(this.BtnGreen_Click);
            // 
            // BtnRed
            // 
            this.BtnRed.BackColor = System.Drawing.Color.Red;
            this.BtnRed.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnRed.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Pink;
            this.BtnRed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnRed.Location = new System.Drawing.Point(451, 31);
            this.BtnRed.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.BtnRed.Name = "BtnRed";
            this.BtnRed.Size = new System.Drawing.Size(404, 260);
            this.BtnRed.TabIndex = 6;
            this.BtnRed.UseVisualStyleBackColor = false;
            this.BtnRed.Click += new System.EventHandler(this.BtnRed_Click);
            // 
            // BtnYellow
            // 
            this.BtnYellow.BackColor = System.Drawing.Color.Yellow;
            this.BtnYellow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnYellow.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightYellow;
            this.BtnYellow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnYellow.Location = new System.Drawing.Point(35, 302);
            this.BtnYellow.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.BtnYellow.Name = "BtnYellow";
            this.BtnYellow.Size = new System.Drawing.Size(404, 260);
            this.BtnYellow.TabIndex = 7;
            this.BtnYellow.UseVisualStyleBackColor = false;
            this.BtnYellow.Click += new System.EventHandler(this.BtnYellow_Click);
            // 
            // BtnBlue
            // 
            this.BtnBlue.BackColor = System.Drawing.Color.Blue;
            this.BtnBlue.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnBlue.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.BtnBlue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnBlue.Location = new System.Drawing.Point(451, 302);
            this.BtnBlue.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.BtnBlue.Name = "BtnBlue";
            this.BtnBlue.Size = new System.Drawing.Size(404, 260);
            this.BtnBlue.TabIndex = 8;
            this.BtnBlue.UseVisualStyleBackColor = false;
            this.BtnBlue.Click += new System.EventHandler(this.BtnBlue_Click);
            // 
            // PnlPlayerButtons
            // 
            this.PnlPlayerButtons.Controls.Add(this.BtnBlue);
            this.PnlPlayerButtons.Controls.Add(this.BtnYellow);
            this.PnlPlayerButtons.Controls.Add(this.BtnRed);
            this.PnlPlayerButtons.Controls.Add(this.BtnGreen);
            this.PnlPlayerButtons.Location = new System.Drawing.Point(133, 324);
            this.PnlPlayerButtons.Margin = new System.Windows.Forms.Padding(4);
            this.PnlPlayerButtons.Name = "PnlPlayerButtons";
            this.PnlPlayerButtons.Size = new System.Drawing.Size(884, 595);
            this.PnlPlayerButtons.TabIndex = 9;
            // 
            // LblGameOver
            // 
            this.LblGameOver.AutoSize = true;
            this.LblGameOver.Font = new System.Drawing.Font("Lucida Sans Unicode", 52.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblGameOver.ForeColor = System.Drawing.Color.Red;
            this.LblGameOver.Location = new System.Drawing.Point(4, 210);
            this.LblGameOver.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblGameOver.Name = "LblGameOver";
            this.LblGameOver.Size = new System.Drawing.Size(876, 168);
            this.LblGameOver.TabIndex = 11;
            this.LblGameOver.Text = "GAME OVER";
            this.LblGameOver.Visible = false;
            // 
            // PnlComputerButtons
            // 
            this.PnlComputerButtons.Controls.Add(this.LblGameOver);
            this.PnlComputerButtons.Controls.Add(this.PnlBlue);
            this.PnlComputerButtons.Controls.Add(this.PnlYellow);
            this.PnlComputerButtons.Controls.Add(this.PnlRed);
            this.PnlComputerButtons.Controls.Add(this.PnlGreen);
            this.PnlComputerButtons.Location = new System.Drawing.Point(133, 324);
            this.PnlComputerButtons.Margin = new System.Windows.Forms.Padding(4);
            this.PnlComputerButtons.Name = "PnlComputerButtons";
            this.PnlComputerButtons.Size = new System.Drawing.Size(884, 595);
            this.PnlComputerButtons.TabIndex = 10;
            // 
            // PnlBlue
            // 
            this.PnlBlue.BackColor = System.Drawing.Color.Blue;
            this.PnlBlue.Location = new System.Drawing.Point(451, 302);
            this.PnlBlue.Margin = new System.Windows.Forms.Padding(4);
            this.PnlBlue.Name = "PnlBlue";
            this.PnlBlue.Size = new System.Drawing.Size(404, 260);
            this.PnlBlue.TabIndex = 12;
            // 
            // PnlYellow
            // 
            this.PnlYellow.BackColor = System.Drawing.Color.Yellow;
            this.PnlYellow.Location = new System.Drawing.Point(35, 302);
            this.PnlYellow.Margin = new System.Windows.Forms.Padding(4);
            this.PnlYellow.Name = "PnlYellow";
            this.PnlYellow.Size = new System.Drawing.Size(404, 260);
            this.PnlYellow.TabIndex = 11;
            // 
            // PnlRed
            // 
            this.PnlRed.BackColor = System.Drawing.Color.Red;
            this.PnlRed.Location = new System.Drawing.Point(451, 31);
            this.PnlRed.Margin = new System.Windows.Forms.Padding(4);
            this.PnlRed.Name = "PnlRed";
            this.PnlRed.Size = new System.Drawing.Size(404, 260);
            this.PnlRed.TabIndex = 10;
            // 
            // PnlGreen
            // 
            this.PnlGreen.BackColor = System.Drawing.Color.Green;
            this.PnlGreen.Location = new System.Drawing.Point(35, 31);
            this.PnlGreen.Margin = new System.Windows.Forms.Padding(4);
            this.PnlGreen.Name = "PnlGreen";
            this.PnlGreen.Size = new System.Drawing.Size(404, 260);
            this.PnlGreen.TabIndex = 9;
            // 
            // LblTitle
            // 
            this.LblTitle.AutoSize = true;
            this.LblTitle.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTitle.ForeColor = System.Drawing.Color.White;
            this.LblTitle.Location = new System.Drawing.Point(217, 11);
            this.LblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblTitle.Name = "LblTitle";
            this.LblTitle.Size = new System.Drawing.Size(719, 110);
            this.LblTitle.TabIndex = 12;
            this.LblTitle.Text = "SIMON GAME";
            // 
            // LblHighScoreMessage
            // 
            this.LblHighScoreMessage.AutoSize = true;
            this.LblHighScoreMessage.Font = new System.Drawing.Font("Cooper Black", 25.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblHighScoreMessage.ForeColor = System.Drawing.Color.Lime;
            this.LblHighScoreMessage.Location = new System.Drawing.Point(247, 936);
            this.LblHighScoreMessage.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblHighScoreMessage.Name = "LblHighScoreMessage";
            this.LblHighScoreMessage.Size = new System.Drawing.Size(657, 79);
            this.LblHighScoreMessage.TabIndex = 13;
            this.LblHighScoreMessage.Text = "New High Score!!!";
            this.LblHighScoreMessage.Visible = false;
            // 
            // BtnReset
            // 
            this.BtnReset.BackColor = System.Drawing.Color.Gainsboro;
            this.BtnReset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnReset.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.BtnReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnReset.Font = new System.Drawing.Font("Calibri", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnReset.ForeColor = System.Drawing.Color.Blue;
            this.BtnReset.Location = new System.Drawing.Point(991, 946);
            this.BtnReset.Margin = new System.Windows.Forms.Padding(4);
            this.BtnReset.Name = "BtnReset";
            this.BtnReset.Size = new System.Drawing.Size(147, 69);
            this.BtnReset.TabIndex = 14;
            this.BtnReset.Text = "Reset High Score ";
            this.BtnReset.UseVisualStyleBackColor = false;
            this.BtnReset.Click += new System.EventHandler(this.BtnReset_Click);
            // 
            // BtnTurboMode
            // 
            this.BtnTurboMode.BackColor = System.Drawing.Color.Black;
            this.BtnTurboMode.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnTurboMode.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.BtnTurboMode.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnTurboMode.Font = new System.Drawing.Font("Calibri", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTurboMode.ForeColor = System.Drawing.Color.LawnGreen;
            this.BtnTurboMode.Location = new System.Drawing.Point(13, 946);
            this.BtnTurboMode.Margin = new System.Windows.Forms.Padding(4);
            this.BtnTurboMode.Name = "BtnTurboMode";
            this.BtnTurboMode.Size = new System.Drawing.Size(147, 69);
            this.BtnTurboMode.TabIndex = 15;
            this.BtnTurboMode.Text = "TURBO";
            this.BtnTurboMode.UseVisualStyleBackColor = false;
            this.BtnTurboMode.Click += new System.EventHandler(this.BtnTurboMode_Click);
            // 
            // FrmSimon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1151, 1044);
            this.Controls.Add(this.BtnTurboMode);
            this.Controls.Add(this.BtnReset);
            this.Controls.Add(this.LblHighScoreMessage);
            this.Controls.Add(this.LblTitle);
            this.Controls.Add(this.BtnStart);
            this.Controls.Add(this.TBHighScore);
            this.Controls.Add(this.LblHighScore);
            this.Controls.Add(this.TBCurrentScore);
            this.Controls.Add(this.LblCurrentScore);
            this.Controls.Add(this.PnlComputerButtons);
            this.Controls.Add(this.PnlPlayerButtons);
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.MaximumSize = new System.Drawing.Size(1177, 1115);
            this.MinimumSize = new System.Drawing.Size(1177, 1115);
            this.Name = "FrmSimon";
            this.Text = "Simon Game";
            this.Load += new System.EventHandler(this.FrmSimon_Load);
            this.PnlPlayerButtons.ResumeLayout(false);
            this.PnlComputerButtons.ResumeLayout(false);
            this.PnlComputerButtons.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnStart;
        private System.Windows.Forms.Label LblCurrentScore;
        private System.Windows.Forms.TextBox TBCurrentScore;
        private System.Windows.Forms.Label LblHighScore;
        private System.Windows.Forms.TextBox TBHighScore;
        private System.Windows.Forms.Button BtnGreen;
        private System.Windows.Forms.Button BtnRed;
        private System.Windows.Forms.Button BtnYellow;
        private System.Windows.Forms.Button BtnBlue;
        private System.Windows.Forms.Panel PnlPlayerButtons;
        private System.Windows.Forms.Panel PnlComputerButtons;
        private System.Windows.Forms.Panel PnlBlue;
        private System.Windows.Forms.Panel PnlYellow;
        private System.Windows.Forms.Panel PnlRed;
        private System.Windows.Forms.Panel PnlGreen;
        private System.Windows.Forms.Label LblGameOver;
        private System.Windows.Forms.Label LblTitle;
        private System.Windows.Forms.Label LblHighScoreMessage;
        private System.Windows.Forms.Button BtnReset;
        private System.Windows.Forms.Button BtnTurboMode;
    }
}

