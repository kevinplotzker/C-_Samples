﻿/*
    Kevin Plotzker
    CISS 233
    4/11/2016

    SimonForm.cs

    This program will create a Windows Form Application that will simulate a Simon Game.
    Program generates a List of random moves, which cause buttons to change color and sounds to paly, 
    after which the user must mimic the computer moves.  Game is over when the user presses the wrong 
    button.  High score is stored in a local database, and a reset button is provided to clear existing 
    high scores.
*/

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Media;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace SImonGame {

    public partial class FrmSimon : Form {

        public static List<int> simonMoves = new List<int>();  //List to hold random Simon moves, replayed and added to each move
        public static int simonCounter = 0;  //Index variable which increments to check user moves
        public static Random randomNumber = new Random(); //Variable to hold random number for Simon move
        public static String directory = AppDomain.CurrentDomain.BaseDirectory;  //Used with tonesPath variable to point to sounds folder
        String tonesPath = directory.Remove(directory.Length - 10) + "SimonTones";
        public static int currentScore = 0;  //User's current game score
        public static String highScoreString = "0";  //Initial placeholder if no scores are in the database
        public static bool playing;  //Flag to indicate the game is still in progress.  Changes to false when user makes error
        public static bool turbo = false;  //Flag to indicate if turbo mode is active

        //Constructor method to load form
        public FrmSimon() {
            InitializeComponent();
            TBCurrentScore.Text = currentScore.ToString();  //Sets current user score to zero
            PnlComputerButtons.Visible = true;  //Makes Simon buttons visible
            PnlPlayerButtons.Visible = false;  //Hides user buttons to prevent clicking
            SetHighScore();  //Querys database to retrieve the current highest stored score
        }

        //Method to retrieve current highest score
        public void SetHighScore() {

            int nbrScores = DataUtilityClass.checkForScores();  //Checks the number of stored scores

            if (nbrScores == 0) {  //Sets high score to zero if no scores are stored
                TBHighScore.Text = highScoreString;
            }
            else {
                int highest = DataUtilityClass.getMaxScore();  //Runs query to retrieve max score for display
                TBHighScore.Text = highest.ToString();
            }
        }

        //Method to start game when Start button is clicked
        private void BtnStart_Click(object sender, EventArgs e) {
            BtnReset.Enabled = false;  //Disables start, turbo, and reset buttons
            BtnStart.Enabled = false;
            BtnTurboMode.Enabled = false;
            LblHighScoreMessage.Visible = false;  //Hides Game Over and high score messages
            LblGameOver.Visible = false;
            SetHighScore();  //Calls method to display highest score in database
            TBCurrentScore.Text = currentScore.ToString();  //Sets current score to zero
            playing = true;  //Changes flag and start button text
            BtnStart.Text = "GAME ON";
            simonCounter = 0;  //Resets Simon index variable and calls method to generate random Simon move
            SimonMove();
        }

        //Method to generate a random number from 1-4 for Simon move
        static int getRandomIntInclusive(int min, int max) {
            return (randomNumber.Next(min, max + 1));
        }

        //Method to coordinate Simon move
        private async void SimonMove() {

            PnlComputerButtons.Visible = true;  //Makes Simon buttons visible, hides player buttons to prevent clicking
            PnlPlayerButtons.Visible = false;
            int delay;  //Variable to hold initial delay time between Simon moves

            int simonMove = getRandomIntInclusive(1, 4);  //Gets random int from 1-4
            simonMoves.Add(simonMove);  //Adds int to List of Simon moves

            if (turbo) {  //Sets permanent delay of 250ms if Turbo mode is enabled
                delay = 250;
            }
            else {
                switch (simonMoves.Count) {  //Increases speed of Simon moves as round continues
                    case 1:
                    case 2:
                    case 3:
                        delay = 800;
                        break;
                    case 4:
                    case 5:
                        delay = 700;
                        break;
                    case 6:
                    case 7:
                        delay = 600;
                        break;
                    case 8:
                    case 9:
                    case 10:
                        delay = 500;
                        break;
                    default:
                        delay = 400;
                        break;
                }
            }
            
            //Loops through list, plays sound and changes button color corresponding to random int
            for (int i = 0; i < simonMoves.Count; i++) {

                switch (simonMoves[i]) {

                    case 1: //Plays green sound and changes green button color 
                        await Task.Delay(100);
                        playSimpleSound(tonesPath + "/green.wav");  //Plays sound
                        PnlGreen.BackColor = Color.Lime;  //Changes button color to lighter
                        await Task.Delay(delay);  //Waits for delay interval
                        PnlGreen.BackColor = Color.Green;  //Changes button color back
                        break;

                    case 2:  //Plays red sound and changes red button color
                        await Task.Delay(100);
                        playSimpleSound(tonesPath + "/Red.wav");
                        PnlRed.BackColor = Color.Pink;
                        await Task.Delay(delay);
                        PnlRed.BackColor = Color.Red;
                        break;

                    case 3:   //Plays yellow sound and changes yellow button color
                        await Task.Delay(100);
                        playSimpleSound(tonesPath + "/Yellow.wav");
                        PnlYellow.BackColor = Color.LightYellow;
                        await Task.Delay(delay);
                        PnlYellow.BackColor = Color.Yellow;
                        break;

                    case 4:  //Plays blue sound and changes blue button color
                        await Task.Delay(100);
                        PnlBlue.BackColor = Color.Black;
                        playSimpleSound(tonesPath + "/Blue.wav");
                        PnlBlue.BackColor = Color.Cyan;
                        await Task.Delay(delay);
                        PnlBlue.BackColor = Color.Blue;
                        break;
                }
            }
            PnlComputerButtons.Visible = false;  //After checking all spots in list, hides Simon buttons and makes user buttons active
            PnlPlayerButtons.Visible = true;
        }

        //Method to check if user button press is correct. 
        //Called from each button passes a number and tone filepath
        private async void Check(int move, String tone) {

            if (move == simonMoves[simonCounter]) {  //Checks for match at current index of simonMoves List
                currentScore++;   //Increments score if there is a match
                TBCurrentScore.Text = currentScore.ToString();
                playSimpleSound(tonesPath + tone);  //Plays color tone
                simonCounter++;  //Increments index of simonMoves List
            }
            else {
                GameOver();  //If button does not match current index of simonMoves List, calls GameOver() method
            }
            //If a match is found above, checks if current index is end of List and if flag is still true  
            if (simonCounter == simonMoves.Count && playing) {
                PnlComputerButtons.Visible = true;  //Prepares for next Simon move by switching button panels
                PnlPlayerButtons.Visible = false;
                await Task.Delay(1500);  //Pauses 1.5 seconds
                simonCounter = 0;  //Resets index of simonMoves List to 0
                SimonMove();  //Calls SimonMove() method
            }
        }

        //Method to play error tone and display Game Over Message when wrong button is pressed
        private async void GameOver() {

            PnlComputerButtons.Visible = true;  //Makes Simon buttons visible, hides player buttons to prevent clicking
            PnlPlayerButtons.Visible = false;
            playSimpleSound(tonesPath + "/Error.wav");  //Plays error tone
            simonMoves.Clear();  //Clears simonMoves List for next game
            LblGameOver.Visible = true;  //Displays Game Over message
            BtnStart.Text = "PLAY AGAIN";  //Changes start button text
            BtnStart.Enabled = true;  //Enables start, turbo, and score reset buttons
            BtnReset.Enabled = true;
            BtnTurboMode.Enabled = true;
            playing = false;  //Changes flag to indicate game over

            int highScore = Convert.ToInt16(TBHighScore.Text);   //Converts currently displayed high score to int

            if (currentScore > highScore) {  //Checks if player achieved a new high score
                DataUtilityClass.AddScore(TBCurrentScore.Text);  //If score is new high score, adds to database and displays message

                for (int i = 0; i < 5; i++) {  //Flashes high score message
                    LblHighScoreMessage.Visible = true;
                    await Task.Delay(700);
                    LblHighScoreMessage.Visible = false;
                    await Task.Delay(300);
                }
                LblHighScoreMessage.Visible = true;
            }
            currentScore = 0;  //Resets current score to zero for next game
        }

        //Method to play sound when correct button is pressed by user or computer
        private void playSimpleSound(String e) {
            SoundPlayer simpleSound = new SoundPlayer(e);
            simpleSound.Play();
        }

        //Methods for each color button.  Calls check with appropriate parameters
        private void BtnGreen_Click(object sender, EventArgs e) {
            //Check(1, BtnGreen, "/green.wav", Color.Lime, Color.Green);
            Check(1, "/green.wav");
        }
        private void BtnRed_Click(object sender, EventArgs e) {
            // Check(2, BtnRed, "/Red.wav", Color.Pink, Color.Red);
            Check(2, "/Red.wav");
        }
        private void BtnYellow_Click(object sender, EventArgs e) {
            //Check(3, BtnYellow, "/Yellow.wav", highlight, Color.Yellow);
            Check(3, "/Yellow.wav");
        }
        private void BtnBlue_Click(object sender, EventArgs e) {
            //Check(4, BtnBlue, "/Blue.wav", Color.Cyan, Color.Blue);
            Check(4, "/Blue.wav");
        }

        //Method to reset high score to zero when reset button is pressed
        private void BtnReset_Click(object sender, EventArgs e) {

            //Displays dialog box to ensure user intends to delete high score
            DialogResult dialog = MessageBox.Show("Are you sure you want to clear the high score?  This cannot be undone.", 
                                              "Delete High Score", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if (dialog == DialogResult.Yes) {  //Deletes all records from database if user clicks "Yes" in dialog box
                DataUtilityClass.ResetHighScore();
                TBHighScore.Text = "0";
            }
        }

        //Method to toggle Turbo Mode when Turbo button is clicked
        private void BtnTurboMode_Click(object sender, EventArgs e) {

            if (BtnTurboMode.BackColor == Color.Black) {
                BtnTurboMode.BackColor = Color.LimeGreen;
                BtnTurboMode.ForeColor = Color.Black;
                turbo = true;
            }
            else {
                BtnTurboMode.BackColor = Color.Black;
                BtnTurboMode.ForeColor = Color.LimeGreen;
                turbo = false;
            }
        }
        
        //Do NOT Remove.  Auto generated and will throw error if removed
        private void FrmSimon_Load(object sender, EventArgs e) {

        }
    }
}